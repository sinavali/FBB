import { IMSS } from "@shared/Types/Interfaces/general.ts";
import Query from "@shared/Queries.ts";
import { GeneralStore } from "@shared/Types/Interfaces/generalStore.ts";
import logger from "@shared/Initiatives/Logger.ts";
import { CandleDeepType, CandleDirection } from "@shared/Types/Enums.ts";
import { CircularBuffer } from "@tradingBot/Features/Core/CircularBuffer.ts";

export default class MarketShiftStructure {
  public marketShifts: CircularBuffer<IMSS>;
  private generalStore: GeneralStore;
  public queryClass: Query;
  private indexMap: Map<number, number> = new Map();
  private maxId: number = 0;

  // capacity = 22000 means 2 weeks and 4 days of 1-minute candles
  constructor(generalStoreInstance: any, capacity: number = 66000) {
    this.generalStore = generalStoreInstance;
    this.queryClass = new Query(this.generalStore);
    this.marketShifts = new CircularBuffer<IMSS>(capacity);
  }

  getMaxId(): number {
    return this.maxId;
  }

  getIndexById(id: number): number | undefined {
    return this.indexMap.get(id);
  }

  processMSS() {}
}
