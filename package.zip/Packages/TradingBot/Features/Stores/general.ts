const glob: any = {
  number: 1,
};

export default glob;
