import { ModelOneData } from "@shared/Types/Interfaces/general.ts";
import { GeneralStore } from "@shared/Types/Interfaces/generalStore.ts";
import { checkForHunt } from "@tradingBot/Features/Features/Liquidity/Controllers/HuntController.ts";
import { validateLiquidities } from "@tradingBot/Features/Features/Liquidity/Validations.ts";

export async function modelOne(generalStore: GeneralStore) {
  await initiationPhaseModelOne(generalStore);
  await updatePhaseModelOne(generalStore);
}

// should initiate data here (finding new MSS, COB, Liquidity and ...)
async function initiationPhaseModelOne(generalStore: GeneralStore) {
  const data: ModelOneData = {
    timezone:
      generalStore.state.Setting?.getOne("BotTimezone")?.settingValueParsed,
    isInSession: false,
    isInWorkTime: false,
    candle: null,
    latestSession: null,
    latestWorkTime: null,
  };

  const candle = generalStore.state.Candle?.candles.getNewest();
  if (!candle) return;
  data.candle = candle;

  // create new session if needed and get the latest session
  const session = generalStore.state.Session?.handleSessionForFlow(
    data.candle.time.unix
  );
  if (session) generalStore.state.MicroTime?.newMicroTimeForSession(session);
  data.latestSession = session ?? null;

  // check if this candle is inside a session
  data.isInSession = !!generalStore.state.Session?.isUnixInSessionRecords(
    data.candle.time.unix
  );

  // create new workTime if needed and get the latest workTime
  const workTime = generalStore.state.WorkTime?.handleWorkTimeForFlow(
    data.candle.time.unix
  );
  if (workTime) generalStore.state.MicroTime?.newMicroTimeForWorkTime(workTime);
  data.latestWorkTime = workTime ?? null;

  // check if this candle is inside a workTime
  data.isInWorkTime = !!generalStore.state.WorkTime?.isUnixInWorkTimeRecords(
    data.candle.time.unix
  );

  // generate liquidities if not exists
  if (generalStore.state.Liquidity && data.timezone) {
    generalStore.state.Liquidity.generateLiquidities({
      type: "daily",
      candle: data.candle,
      timezone: data.timezone,
    });
    generalStore.state.Liquidity.generateLiquidities({
      type: "weekly",
      candle: data.candle,
      timezone: data.timezone,
    });

    if (data.latestSession) {
      generalStore.state.Liquidity.generateLiquidities({
        type: "bySession",
        pairPeriod: data.candle.pairPeriod,
        session: data.latestSession,
      });
    }
  }

  // validate and update all liquidities
  validateLiquidities(generalStore);

  generalStore.state.COB?.initiateCOB(data.candle);
}

// should update liquidities, COBs, MSSs and signals here
async function updatePhaseModelOne(generalStore: GeneralStore) {
  const liquidities = generalStore.state.Liquidity?.liquidities
    .getAll()
    .filter((l) => !l.failed && !l.hunted);

  if (liquidities)
    for (let i = 0; i < liquidities.length; i++)
      checkForHunt(generalStore, liquidities[i]);
}
