import logger from "@shared/Initiatives/Logger.ts";
import { IQuery } from "@shared/Types/Interfaces/general.ts";
import { GeneralStore } from "@shared/Types/Interfaces/generalStore.ts";

export default (generalStore: GeneralStore) => {
  try {
  } catch (error) {
    logger.error(error);
  }
};
