import logger from "@shared/Initiatives/Logger.ts";
import { LiquidityMode } from "@shared/Types/Enums.ts";
import { GeneralStore } from "@shared/Types/Interfaces/generalStore.ts";
import { modelOne } from "@tradingBot/Features/Core/Controllers/flows.ts";
import moment from "moment";

export default async (generalStore: GeneralStore) => {
  try {
    const start = generalStore.state.Setting.getOne("BackTestStartUTCUnix");
    const end = generalStore.state.Setting.getOne("BackTestEndUTCUnix");

    if (!start || !end) {
      if (!start && !end) {
        logger.error("start and end of test are not specified");
        console.log("start and end of test are not specified");
      } else if (!start) {
        logger.error("start of test is not specified");
        console.log("start of test is not specified");
      } else if (!end) {
        logger.error("end of test is not specified");
        console.log("end of test is not specified");
      }
      return;
    }
    console.log(
      `from: ${moment
        .unix(start.settingValueParsed)
        .format("YYYY-MM-DD HH:mm")} to: ${moment
        .unix(end.settingValueParsed)
        .format("YYYY-MM-DD HH:mm")}`
    );

    await generalStore.state.Candle?.startCandleProcesses(
      {
        from: start.settingValueParsed,
        to: end.settingValueParsed,
        chunkSize: 10000,
      },
      modelOne
    );

    console.log(
      `time range from ${moment.utc(1546350000)} to ${moment.utc(1547350000)}`
    );
    console.log(
      "candles",
      generalStore.state.Candle.candles.getAll().length,
      generalStore.state.Candle.candles.getNewest()?.id
    );
    console.log(
      "sessions",
      generalStore.state.Session.sessions.getAll().length,
      generalStore.state.Session.sessions.getNewest()?.id
    );
    console.log(
      "workTimes",
      generalStore.state.WorkTime.workTimes.getAll().length,
      generalStore.state.WorkTime.workTimes.getNewest()?.id
    );
    console.log(
      "microTimes",
      generalStore.state.MicroTime.microTimes.getAll().length,
      generalStore.state.MicroTime.microTimes.getNewest()?.id
    );
    console.log(
      "Liquidities",
      generalStore.state.Liquidity.liquidities.getAll().length,
      generalStore.state.Liquidity.liquidities.getNewest()?.id,
      "bySession",
      generalStore.state.Liquidity.liquidities.getAll([
        ["mode", LiquidityMode.BYSESSION],
      ]).length,
      "failed: ",
      generalStore.state.Liquidity.liquidities.getAll([["failed", true]])
        .length,
      "hunted: ",
      generalStore.state.Liquidity.liquidities.getAll([
        ["hunted", undefined, "!=="],
      ]).length
    );
    console.log(
      "COB",
      generalStore.state.COB.orderBlocks.getAll().length,
      generalStore.state.COB.orderBlocks.getNewest()?.id
    );
    console.log(
      "MSS",
      generalStore.state.MSS.marketShifts.getAll().length,
      generalStore.state.MSS.marketShifts.getNewest()?.id
    );
  } catch (error) {
    console.log(error);
    logger.error(error);
  }
};
