export const FBB_Bot_DB_USER = "root";
export const FBB_Bot_DB_HOST = "localhost";
export const FBB_Bot_DB_PASSWORD = "qwerty";
export const FBB_Bot_DB_NAME = "fbb_core";
export const FBB_Bot_BACKTEST_DB_NAME = "fbb_test_candles";
